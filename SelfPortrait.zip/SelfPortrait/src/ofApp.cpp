#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw()
{
    ofBackgroundGradient(ofColor::paleTurquoise, ofColor::violet, OF_GRADIENT_LINEAR);
   
    ofNoFill();
    ofSetColor(255);
    ofDrawTriangle(450,150,400,450,500,450);
    
    
}
