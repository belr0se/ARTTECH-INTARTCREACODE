#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){

}

//--------------------------------------------------------------
void ofApp::update(){

}

//--------------------------------------------------------------
void ofApp::draw(){
    ofSetBackgroundColor(ofColor::white);
    int width = ofGetWidth();
    int height = ofGetHeight();
    ofSetLineWidth(10);
    
    ofSetColor(ofColor::grey);
    ofDrawLine(55,0,55,400);
    ofDrawLine(110,0,110,400);
    ofDrawLine(165,0,165,400);
    ofDrawLine(220,0,220,400);
    ofDrawLine(275,0,275,400);
    ofDrawLine(330,0,330,400);
    ofDrawLine(385,0,385,400);
    ofDrawLine(440,0,440,400);
    
    ofSetColor(ofColor::yellow);
    ofDrawLine(500,66,1500,66);
    ofDrawLine(500,132,1500,132);
    ofDrawLine(500,198,1500,198);
    ofDrawLine(500,264,1500,264);
    ofDrawLine(500,330,1500,330);
    
    ofSetColor(ofColor::hotPink);
    ofDrawLine(0, 450, 55, 400);
    ofDrawLine(0, 500, 110, 400);
    ofDrawLine(0, 550, 165, 400);
    ofDrawLine(0, 600, 220, 400);
    ofDrawLine(0, 650, 275, 400);
    ofDrawLine(0, 700, 330, 400);
    ofDrawLine(0, 750, 385, 400);
    ofDrawLine(0, 800, 440, 400);
    ofDrawLine(0, 850, 495, 400);
    ofDrawLine(0, 900, 495, 450);
    ofDrawLine(0, 950, 495, 500);
    ofDrawLine(0, 1000, 495, 550);
    ofDrawLine(0, 1050, 495, 600);
    ofDrawLine(0, 1100, 495, 650);
    ofDrawLine(0, 1150, 495, 700);
    ofDrawLine(0, 1200, 495, 750);
    ofDrawLine(0, 1250, 495, 800);
    
    ofSetColor(ofColor::lightBlue);
    ofDrawLine(1000,400, 1000,400);
    ofDrawLine(900,400, 1050,500);
    ofDrawLine(800,400, 1100,600);
    ofDrawLine(700,400, 1150,700);
    ofDrawLine(600,400, 1200,800);
    ofDrawLine(500,400, 1250,900);
    ofDrawLine(500,450, 1300,1000);
    ofDrawLine(500,500, 1350,1100);
    ofDrawLine(500,550, 1400,1200);
    ofDrawLine(500,600, 1450,1300);
    ofDrawLine(500,650, 1500,1400);
    ofDrawLine(500,700, 1550,1500);
    ofDrawLine(500,750, 1600,1600);
    
    ofSetColor(ofColor::black);
    ofDrawLine(0, 400, 1500, 400);
    ofDrawLine(500,1500,500,0);
}
